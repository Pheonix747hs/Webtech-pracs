<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">

    <style>
        .row {
            display: flex;
        }

        .left {
            width: 10%;
        }

        .center1 {
            width: 40%;
        }

        .center2 {
            width: 40%;
        }

        img {
            border-radius: 10px;
        }
    </style>
</head>

<body style="margin-bottom: 100px;">
    <div>
        <ul>
            <li style="margin-left: 475px; margin-top: 8px;"><a href="menu.html">Menu</a></li>
            <li style=" padding: 0%;"><a href="index.html"><img src="assets/logo1.png" alt="" width="40%"></a></li>
            <li style=" margin-top: 8px;"><a href="contact.html">Contact</a></li>
        </ul>
    </div>
    <div style="margin-top: 50px;">
        <?php
        
        require_once('connect.php');
      
        // Define an empty array to store menu items
        $menu_items = array();
      
        // SQL query to fetch all menu items
        $sql = "SELECT * FROM menu_items";
        $result = mysqli_query($conn, $sql);
      
        // Check for successful query execution
        if ($result) {
          // Loop through each row in the result set
          while ($row = mysqli_fetch_assoc($result)) {
            // Extract menu item details from the row
            $menu_items[] = array(
              "name" => $row["name"],
              "description" => $row["description"],
              "price" => $row["price"],
              "image_url" => $row["image_url"],
            );
          }
        } else {
          echo "Error fetching menu items: " . mysqli_error($conn);
        }
      
        // Close the connection
        mysqli_close($conn);
        ?>
        <?php if (count($menu_items) > 0): ?>
        <?php foreach ($menu_items as $item): ?>
        <div class="menu-item">
        <div class="row">
            <div class="column left"></div>
            <div class="column center1">
                <img src="<?php echo $item['image_url']; ?>" alt="" width="100%">
            </div>
            <div class="column center2" style=" padding-left: 50px; margin-top: 70px;">
                <h1><?php echo $item['name']; ?></h1>
                <p><?php echo $item['description']; ?></p>
                <h3><?php echo number_format($item['price'], 2); ?></h3>
            </div>
            <div class="column left"></div>
        </div>
        <?php endforeach; ?>
        <?php else: ?>
        <p>No menu items found.</p>
        <?php endif; ?>
    </div>
    </div>


</body>

</html>