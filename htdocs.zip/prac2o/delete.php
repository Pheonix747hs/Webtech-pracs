<?php

require_once('connect.php');

$phoneNumber = isset($_GET['phoneNumber']) ? (int) $_GET['phoneNumber'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $sql = "SELECT * FROM bookings WHERE phoneNumber = $phoneNumber";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $booking = mysqli_fetch_assoc($result);
  } else {
    header('Location: in2.php');
    exit();
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Delete Booking</title>
</head>
<body>
  <h1>Delete Booking</h1>
  <?php if (isset($booking)): ?>
    <p>Are you sure you want to delete this booking for "<?php echo $booking['name']; ?>"?</p>
    <a href="?id=<?php echo $phoneNumber; ?>&confirm=1">Yes</a>
    <a href="in2.php">No</a>
  <?php else: ?>
    <p>Booking not found.</p>
  <?php endif; ?>

  <?php
  if (isset($_GET['confirm'])) {
    $sql = "DELETE FROM bookings WHERE phoneNumber = $phoneNumber";
    mysqli_query($conn, $sql);
    header('Location: in2.php');
    exit();
  }
  ?>
</body>
</html>
