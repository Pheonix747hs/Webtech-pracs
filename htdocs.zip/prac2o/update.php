<?php

require_once('connect.php');

$phoneNumber = isset($_GET['phoneNumber']) ? (int) $_GET['phoneNumber'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $sql = "SELECT * FROM bookings WHERE phoneNumber = $phoneNumber";
  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $booking = mysqli_fetch_assoc($result);
  } else {
    header('Location: in2.php');
    exit();
  }
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $guests = $_POST['guests'];
  $timeSlot = $_POST['timeSlot'];
  $phone = $_POST['phoneNumber'];

  $sql = "UPDATE bookings SET name = '$name', email = '$email', guests = $guests, timeslot = '$timeslot', phone = '$phoneNumber' WHERE id = $id";

  if (mysqli_query($conn, $sql)) {
    header('Location: in2.php');
  } else {
    echo "Error: Could not update booking.";
  }

  mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Booking</title>
</head>
<body>
  <h1>Update Booking</h1>
  <?php if (isset($booking)): ?>
  <form action="" method="post">
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" value="<?php echo $booking['name']; ?>" required>
    <br>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" value="<?php echo $booking['email']; ?>" required>
    <br>
    <label for="guests">Number of Guests:</label>
    <input type="number" name="guests" id="guests" value="<?php echo $booking['guests']; ?>" required>
    <br>
    <label for="timeSlot">Desired Time Slot:</label>
    <input type="text" name="timeSlot" id="timeSlot" value="<?php echo $booking['timeslot']; ?>" required>
    <br>
    <label for="phone">Phone Number:</label>
    <input type="tel" name="phone" id="phone" value="<?php echo $booking['phoneNumber']; ?>" required>
    <br>
    <button type="submit">Update Booking</button>
  </form>
  <?php else: ?>
  <p>Booking not found.</p>
  <?php endif; ?>
</body>
</html>
