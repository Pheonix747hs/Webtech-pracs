<?php

  $name = $_POST['name'];
  $email_id = $_POST['email_id'];
  $msg = $_POST['msg'];
  $phone = $_POST['phone'];

  // Construct email body message
  $body = "thank you for contacting us!\n\n";
  $body .= "Name: $name\n";
  $body .= "Email: $email_id\n";
  $body .= "Phone Number: $phone\n";
  $body .= "Selected Time Slot: $msg\n\n";
  $body .= "Please respond to this email to confirm your booking.\n";

  // Email headers
  $recipientEmail = 'ojasvinborawke@gmail.com';
  $subject = 'e21312312n';
  $headers = "From: wfqeineqrwenoewq\n";
  $headers .= "Reply-To: $email_id\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\n";

  // Send email using PHP mail function
  if (mail($email_id, $subject, $body, $headers)) {
    echo "thank you for contacting us!$email_id";
  } else {
    echo 'There was an error sending the email. Please try again later.';
  }

?>
