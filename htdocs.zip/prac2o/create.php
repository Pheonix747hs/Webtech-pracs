<?php

require_once('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $guests = $_POST['guests'];
  $timeSlot = $_POST['timeSlot'];
  $phone = $_POST['phone'];

  $sql = "INSERT INTO bookings (name, email, guests, timeSlot, phoneNumber) VALUES ('$name', '$email', $guests, '$timeSlot', '$phone')";

  if (mysqli_query($conn, $sql)) {
    header('Location: in2.php'); // Redirect on success
  } else {
    echo "Error: Could not add reservation.";
  }

  mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Reservation</title>
</head>
<body>
  <h1>Make a Reservation</h1>
  <form action="" method="post">
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" required>
    <br>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email" required>
    <br>
    <label for="guests">Number of Guests:</label>
    <input type="number" name="guests" id="guests" required>
    <br>
    <label for="timeSlot">Desired Time Slot:</label>
    <input type="text" name="timeSlot" id="timeSlot" required>
    <br>
    <label for="phone">Phone Number:</label>
    <input type="tel" name="phone" id="phone" required>
    <br>
    <button type="submit">Make Reservation</button>
  </form>
</body>
</html>
