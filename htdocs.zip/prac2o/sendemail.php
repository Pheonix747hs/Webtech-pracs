<?php

// Database connection (assuming 'connect.php' exists)
require_once('connect.php');

// Capture form data
$name = $_POST['name'];
$email = $_POST['email'];
$guests = $_POST['guests'];
$timeSlot = $_POST['timeSlot'];
$phoneNumber = $_POST['phoneNumber'];

// Database insert (improved security)
$sql = "INSERT INTO bookings (name, email, guests, timeSlot, phoneNumber) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "sssss", $name, $email, $guests, $timeSlot, $phoneNumber);

if (mysqli_stmt_execute($stmt)) {
  $booking_id = mysqli_insert_id($conn); // Get the newly inserted ID

  // Construct email body message
  $body = "You have a new table booking at Wasabi! (Booking ID: $booking_id)\n\n";
  $body .= "Name: $name\n";
  $body .= "Email: $email\n";
  $body .= "Phone Number: $phoneNumber\n";
  $body .= "Number of Guests: $guests\n";
  $body .= "Selected Time Slot: $timeSlot\n\n";
  $body .= "Please respond to this email to confirm your booking.\n";

  // Email headers
  $recipientEmail = 'ojasvinborawke@gmail.com';
  $subject = 'Wasabi Table Booking Confirmation';
  $headers = "From: Wasabi Restaurant <noreply@wasabi.com>\n";
  $headers .= "Reply-To: $email\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\n";

  // Send email using PHP mail function
  if (mail($recipientEmail, $subject, $body, $headers)) {
    echo 'Your booking has been submitted successfully! (Booking ID: ' . $booking_id . '). We will confirm your booking via email.';
  } else {
    echo 'There was an error sending the email. Please try again later.';
  }
} else {
  echo 'Error: Could not add booking to database.';
}

// Close database connection
mysqli_stmt_close($stmt);
mysqli_close($conn);

?>
